import React, { Component } from 'react'
import { Card, CardContent, Grid, FormControl, TextField, Input, FormHelperText, OutlinedInput ,Select } from '@material-ui/core';
import { Paper, Typography, AppBar, Toolbar, Button, IconButton ,Divider,Box } from "@material-ui/core";
import { makeStyles } from '@material-ui/core/styles';
import InputLabel from '@material-ui/core/InputLabel';

import ApiService from "../../ApiService";



import AddBox from '@material-ui/icons/AddBox';




import '../css/addOrder.css';

// const style ={
//   float:'right',
//   marginRight:'50px',
//   marginTop:'30px',
// }

class AddOrder extends Component {

    constructor(props){
        super(props);
        this.state ={
          id:'',
          username:'',
          userId:'',
          productId: '',
          shopId:'',
          title:'',
          time:'',
          date:'',
          price:'',
          quantity:'',
          email:'',
          phoneNumber:'',
          address:'',

          Total_no_of_pages:'',

          user:[],
          product:[],
        }
        // this.saveUser = this.saveUser.bind(this);
        // this.loadUser = this.loadUser.bind(this);
    }



    loadUser = () => {
        ApiService.viewUserByUserName(this.state.username)
            .then(res => {
                let user = res.data;
                this.setState({
                    user:user,
                    userId:user.userId,
                    address:user.address,
                    email:user.email,
                    phoneNumber:user.phoneNumber
                })
            })
            .catch(error => {
                this.setState({message : 'User details get failed.'});
            })
    }

    loadProduct = () =>{
      ApiService.getProductById(this.state.productId)
            .then(res => {
                let product = res.data;

                this.setState({
                    product:product,
                    price:product.sellPrice,
                    shopId:product.shopId,
                    title:product.title,


                })
            })
            .catch(error => {
                this.setState({message : 'Product details get failed.'});
            })
    }



    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });

    AddOrder = (e) => {
      alert('hii')
        e.preventDefault();
        let order = {
          	shopId:this.state.shopId,
          	userId:this.state.userId,
          	buyProductDetails:[
          		{
            		buyProductId:this.state.productId,
            		quantity:this.state.quantity,
            		price:this.state.price
          	   }
            ]
          };
        ApiService.addOrder(order)
            .then(res => {
                this.setState({message : 'User added successfully.'});
                this.props.history.push('/orderDetails');
            });
    }

    render() {
      const user = this.state.user;
      const product = this.state.product;

        return (
            <div>
            <Paper className='addOrderWarraper' elevation={1}>
              <Typography id="profileHeading">Add Order</Typography>
                <Grid container style={{width:'100%'}}>

                <Paper className="addOrderUserDetail"  elevation={5}>
                <Grid container >

                      <Grid item xs={12} sm={12} md={6}>
                        <Paper id="userNameDiv" elevation={3}>
                            <Typography variant="h6" id="userNameDivTitle">User name</Typography>
                            <FormControl variant="outlined" id='firstNameIp'>
                                <InputLabel htmlFor="component-outlined">User name</InputLabel>
                                <OutlinedInput
                                    id="component-outlined"
                                    value={this.state.username}
                                    onChange={this.onChange}
                                    label="User name"
                                    name="username"
                                />
                            </FormControl>
                            <Box style={{float:'right',  marginRight:'5%', marginTop:'10px',}}>
                              <Button onClick={this.loadUser} style={{backgroundColor:'white',fontWeight:'bold',backgroundColor:'#03a9f4',color:'white'}}>Get User Details</Button>
                            </Box>
                        </Paper>
                      </Grid>



                      <Grid item xs={12} sm={12} md={6}>

                        <Paper id="emailDiv" elevation={3}>
                            <Box id="emailbox">
                                <Typography variant="h6" id="emailDivTitle">Email</Typography>
                                <Typography variant="h6" style={{marginLeft:'5%'}} >{this.state.email}</Typography>

                            </Box>
                        </Paper>

                      </Grid>



                      <Grid item xs={12} sm={12} md={6}>

                        <Paper id="phoneDiv" elevation={3}>
                            <Box id="phonebox">
                                <Typography variant="h6" id="lastNameDivTitle">Phone Number</Typography>
                                <Typography variant="h6" style={{marginLeft:'5%'}} >{this.state.phoneNumber}</Typography>

                            </Box>
                        </Paper>
                      </Grid>



                      <Grid item xs={12} sm={12} md={6}>

                        <Paper id="addressDiv" elevation={3}>
                            <Box id="addressbox">
                                <Typography variant="h6" id="lastNameDivTitle">Address</Typography>
                                <Typography variant="h6" style={{marginLeft:'5%'}}>{this.state.address}</Typography>
                            </Box>
                        </Paper>
                      </Grid>
                </Grid>
                </Paper>






                      <Grid item xs={12} sm={12} md={12} style={{height:'100px'}}>

                            <Typography variant="h6" style={{textAlign:'center',fontWeight:'bold',marginTop:'60px'}}>Order's Product Details</Typography>
                      </Grid>
                  <Paper className="addOrderUserDetail"  elevation={5}>
                  <Grid container >

                          <Grid item xs={12} sm={12} md={6}>
                            <Paper id="firstNameDiv" elevation={3}>
                                <Box id="firstNamebox">
                                  <Typography variant="h6" id="firstNameDivTitle">Product Id</Typography>

                                      <FormControl variant="outlined" id='firstNameIp'>
                                          <InputLabel htmlFor="component-outlined">Product Id</InputLabel>
                                          <OutlinedInput
                                              id="component-outlined"
                                              value={this.state.productId}
                                              onChange={this.onChange}
                                              label="Product Id"
                                              name="productId"
                                          />
                                      </FormControl>
                                </Box>
                                <Box style={{float:'right',  marginRight:'5%', }}>
                                  <Button onClick={this.loadProduct} style={{backgroundColor:'white',fontWeight:'bold',backgroundColor:'#03a9f4',color:'white'}}>Get Product Details</Button>
                                </Box>
                            </Paper>
                          </Grid>



                          <Grid item xs={12} sm={12} md={6}>
                            <Paper id="lastNameDiv" elevation={3}>
                                <Box id="lastNamebox">
                                    <Typography variant="h6" id="lastNameDivTitle">Title</Typography>
                                    <Typography variant="h6" style={{marginLeft:'5%'}}>{this.state.title}</Typography>
                                </Box>
                            </Paper>
                          </Grid>


                          <Grid item xs={12} sm={12} md={6}>
                            <Paper id="lastNameDiv" elevation={3}>
                                <Box id="lastNamebox">
                                    <Typography variant="h6" id="lastNameDivTitle">Price</Typography>
                                    <Typography variant="h6" style={{marginLeft:'5%'}}>{this.state.price}</Typography>
                                </Box>
                            </Paper>
                          </Grid>


                          <Grid item xs={12} sm={12} md={6}>
                            <Paper id="emailDiv" elevation={3}>
                                <Box id="emailbox">
                                    <Typography variant="h6" id="emailDivTitle">Quantity</Typography>
                                        <FormControl variant="outlined" id='emailIp'>
                                            <InputLabel htmlFor="component-outlined">quantity</InputLabel>
                                            <OutlinedInput
                                                id="component-outlined"
                                                value={this.state.quantity}
                                                onChange={this.onChange}
                                                label="quantity"
                                                type='number'
                                                name="quantity"
                                            />
                                        </FormControl>
                                </Box>
                            </Paper>
                          </Grid>

                      </Grid>
                      </Paper>


                      <Grid item xs={12} sm={12} >
                          <Box style={{height:'150px',float:'right',marginRight:'30px'}}>
                            <Button onClick={this.AddOrder} style={{backgroundColor:'white',fontWeight:'bold',backgroundColor:'#03a9f4',color:'white',marginTop:'20px'}}><AddBox style={{marginRight:'5px'}}/>Add Order</Button>
                          </Box>
                      </Grid>







                </Grid>


            </Paper>
            </div>
        );
    }
}

export default AddOrder;
