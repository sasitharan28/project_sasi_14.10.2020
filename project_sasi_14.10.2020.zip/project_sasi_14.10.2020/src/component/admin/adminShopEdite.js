import React,{Component} from 'react';
import { Card, CardContent, Grid, FormControl, TextField, Input, FormHelperText, OutlinedInput ,Select ,CardActionArea } from '@material-ui/core';
import { Paper, Typography, AppBar, Toolbar, Button, IconButton ,Divider,Box,Link,CardMedia } from "@material-ui/core";
import DelayLink from 'react-delay-link';

import { makeStyles } from '@material-ui/core/styles';
import InputLabel from '@material-ui/core/InputLabel';
import Rating from 'material-ui-rating'
import Logo from './../../ibaseshopLogo.png'

import EditSharpIcon from '@material-ui/icons/EditSharp';
import SaveIcon from '@material-ui/icons/Save';


import ApiService from "../../ApiService";


import './../css/adminShopEdite.css';

class AdminShopEdite extends Component {
  constructor(props){
    super(props)
    this.state={

      shopId: "",
      ownerId: "",
      description: "",
      address: "",
      telephone: "",
      product: "",
      shopName: "",
      shopLogo: "",
      rating: "",

      imagePreviewUrl1:'',
      message:'',

      file1: '',

    }
  }

  componentDidMount() {

      const shopId = this.props.match.params.id;
      this.loadShop(shopId);
  }

  loadShop = (shopId) => {
      ApiService.getShopById(shopId)
          .then((res) => {

              let shops = res.data;
              this.setState({
                  shopId: shops.shopId,
                  ownerId: shops.ownerId,
                  description: shops.description,
                  address: shops.address,
                  telephone: shops.telephone,
                  product: shops.product,
                  shopName: shops.shopName,
                  shopLogo: shops.shopLogo,
                  rating: shops.rating,

                  file1: shops.shopLogo,

              })
          });

  }

  formUpdate = () => {

    let shop = {
        shopId: this.state.shopId,
        ownerId: this.state.ownerId,
        description: this.state.description,
        address: this.state.address,
        telephone: this.state.telephone,
        product: this.state.product,
        shopName: this.state.shopName,
        shopLogo: this.state.imagePreviewUrl1,
        rating: this.state.rating,

        //file1: shops.shopLogo,
    };
    ApiService.updateShop(shop)
        .then(res => {
            this.setState({message : 'Shop Edit successfully.'});
            setTimeout(() => {
                this.props.history.push('/shopDetails');
                window.location.reload();
            },500)
        });

  }

  _handleImage1Change1(e) {
    e.preventDefault();

    let reader1 = new FileReader();
    let file1 = e.target.files[0];

    reader1.onloadend = () => {
      this.setState({
        file1: file1,
        imagePreviewUrl1: reader1.result
      });
    }

    reader1.readAsDataURL(file1)
  }

  onChangeUpdateShopName = (e) =>{
    this.setState({
        shopName:e.target.value,
    })
  }



  render(){
      let {imagePreviewUrl1} = this.state;


      return(
        <div id="adminShopEditeMainDiv">
        {this.state.message&&(
          <div>
              <div id="shopEditAlertMsgCoverDiv">

              </div>
              <Paper elevation="5" id="shopEditAlertMsgCoverDivPaper" ><Typography variant="h4" style={{textAlign:'center',position:'relative',top:'50px'}}>{this.state.message}</Typography></Paper>
          </div>
        )}
            <Grid container>
                <Grid item xs="12" sm="12" >
                <Box>
                  <Card id="AdminEditeShopLogoCard">
                    <form>
                      <div id="editeLogoImgDiv1">
                          <input className="editeShopLogoFileInput1"
                            type="file"
                            accept="image/*"
                            onChange={(e)=>this._handleImage1Change1(e)}
                           />

                           {!imagePreviewUrl1&&(
                              <img src={this.state.shopLogo} className="editeLogoImg" />
                            )}
                              <img src={imagePreviewUrl1} className="editeLogoImg" />

                      </div>

                      <div id="editeShopNameDiv">
                        <FormControl variant="outlined" id='lastNameIp'>
                            <InputLabel htmlFor="component-outlined">Shop Name</InputLabel>
                            <OutlinedInput
                                id="component-outlined"
                                value={this.state.shopName}
                                onChange={this.onChangeUpdateShopName}
                                label="Shop Name"
                            />
                        </FormControl>
                      </div>
                        <Button id="formUpdateBtn" onClick={()=>this.formUpdate()}><SaveIcon style={{marginRight:'5px'}}/>Update</Button>
                      </form>
                  </Card>
                </Box>
                </Grid>
            </Grid>

            <div id="ediShopCoverDiv"></div>

        </div>
      )
  }
}
export default AdminShopEdite;
