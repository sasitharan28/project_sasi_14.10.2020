import React, { Component } from 'react'
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Button from '@material-ui/core/Button';
import CreateIcon from '@material-ui/icons/Create';
import DeleteIcon from '@material-ui/icons/Delete';
import Typography from '@material-ui/core/Typography';
import Paper from '@material-ui/core/Typography';
import Box from '@material-ui/core/Typography';


import ApiService from "../../ApiService";
import Alert from '@material-ui/lab/Alert';
import AlertTitle from '@material-ui/lab/AlertTitle';


import AddBox from '@material-ui/icons/AddBox';
import AccountBox from '@material-ui/icons/AccountBox';
import Close from '@material-ui/icons/Close';




const style ={
    display: 'flex',
    justifyContent: 'center'
}

class OrderDetails extends Component {

    constructor(props) {
        super(props)
        this.state = {
            orders: [],
            message: '',
            visible:'none',
            buyProductDetails:[],

            visible:'none',
            deleteUserId:'',
            show:false,
            error:false,

            pageSize:20,
            pageNo:0,
            Current_page_no:0,
            Total_no_of_pages:0,
            Total_no_of_elements:0,
            nxtDisabled:false,
            prwDisabled:true,

        }
    }

    componentDidMount() {
        this.reloadOrderList();
    }

    // reloadOrderList = () => {
    //     ApiService.getAllOrders()
    //         .then((res) => {
    //             this.setState({orders: res.data})
    //         });
    // }

    reloadOrderList = () =>{
      ApiService.getAllOrders(this.state.pageNo,2)
          .then((res) => {
            let item=res.data.data;
            this.setState({
                Current_page_no:res.data.Current_page_no,
                Total_no_of_pages:res.data.Total_no_of_pages,
                Total_no_of_elements:res.data.Total_no_of_elements,
            })
              {
                item.map(item =>(
                  ApiService.viewUserById(item.userId)
                      .then((res) => {
                          let userDetails = res.data;
                          this.setState(prevState => ({
                            buyProductDetails:item.buyProductDetails,

                          }))
                          this.setState(prevState => ({
                            orders: [...prevState.orders, {
                              "orderId":item.orderId,
                              "userId":item.userId,
                              "buyProductDetails":item.buyProductDetails,
                              "totalPrice":item.totalPrice,
                              "orderDateTime":item.orderDateTime,
                              //"shopId":userDetails.shopId,
                              "userName":userDetails.userName,
                              "email":userDetails.email,
                              "address":userDetails.address,
                            }]
                          }))
                      })
                ))
              }
          });

    }


    next = () => {
      if(this.state.Total_no_of_pages-1 > this.state.pageNo){
        this.setState({
          pageNo:this.state.pageNo+1,
          nxtDisabled:false,
          prwDisabled:false,
          orders: [],
        })
        setTimeout(() => {
              {this.reloadOrderList()}
        },500);
      }else {
        this.setState({
          nxtDisabled:true,
        })
      }
    }



    preview = () => {
      if(this.state.Current_page_no > 0){
          this.setState({
              pageNo:this.state.pageNo-1,
              prwDisabled:false,
              nxtDisabled:false,
              orders: [],
          })
          setTimeout(() => {
                {this.reloadOrderList()}
          },500);
      }else {
          this.setState({
            prwDisabled:true,
          })
        }
    }



    deleteOrder = (orderId) => {
        this.setState({
            deleteOrderId:`${orderId}`,
            visible:'block',
            show:true,
            error:false,
        })
    }


    handlecoverHide = (e) =>{
      this.setState({
        visible:'none',
        show:false,
        error:false,
        message:'',
      })
    }

    conformDeleteProduct = () =>{

        ApiService.deleteOrderById(this.state.deleteOrderId)
           .then(res => {
               this.setState({message : 'Order deleted successfully.',show:false,error:false});
               this.setState({orders: this.state.orders.filter(orders => orders.orderId !== this.state.deleteOrderId)})
               setTimeout(() => {
                  this.setState({message:'',visible:'none'});
               },1500)
           })
           .catch(error => {
               this.setState({error:true,show:false});
               setTimeout(() => {
                   this.setState({error:false,show:false,visible:'none',});
               },1500);
           })

    }

    // editOrder = (id) => {
    //     window.localStorage.setItem("editOrderId", id);
    //     this.props.history.push('/editOrder');
    // }

    addOrder = () => {
        window.localStorage.removeItem("orderId");
        this.props.history.push('/addOrder');
    }

    render() {

      const orders= this.state.orders

        return (
            <div style={{width:'90%',margin:'auto', backgroundColor:'white' , marginTop:'50px',overflowY: 'auto'}}>
                <br/><br/>
                <Typography variant="h4" style={{display: 'flex',justifyContent: 'center'}}>Order Details</Typography><br/>
                <Button variant="contained" style={{backgroundColor:'#03a9f4',color:'white',float:'left',marginLeft:'30px',fontWeight:'bold'}} onClick={() => this.addOrder()}><AddBox style={{marginRight:'5px'}}/>
                    Add Order
                </Button>
                <br/><br/><br/><br/>


                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell align="center">Order Id</TableCell>
                            <TableCell align="center">UserName</TableCell>
                            <TableCell align="center">Email</TableCell>
                            <TableCell align="center">Address</TableCell>
                            <TableCell align="center">Date</TableCell>
                            <TableCell align="center">Total Price</TableCell>

                            <TableCell align="center"> Buy Product Details</TableCell>



                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {orders.map(row => (
                            <TableRow key={row.orderId}>
                                <TableCell component="th" scope="row">
                                    {row.orderId}
                                </TableCell>
                                <TableCell align="left">{row.userName}</TableCell>
                                <TableCell align="left">{row.email}</TableCell>
                                <TableCell align="left">{row.address}</TableCell>
                                <TableCell align="left">{row.orderDateTime}</TableCell>
                                <TableCell align="left">{row.totalPrice}</TableCell>

                                <TableCell align="left">
                                  <TableRow>
                                      <TableCell align="left">Index</TableCell>
                                      <TableCell align="left">Product Id</TableCell>
                                      <TableCell align="left">Shop Id</TableCell>
                                      <TableCell align="left">Quantity</TableCell>
                                      <TableCell align="left">Price</TableCell>
                                  </TableRow>
                                  {row.buyProductDetails.map((row2, index)=>(
                                    <TableRow key={index}>
                                        <TableCell align="left">{index+1}</TableCell>
                                        <TableCell align="left">{row2.buyProductId}</TableCell>
                                        <TableCell align="left">{row2.shopId}</TableCell>
                                        <TableCell align="left">{row2.quantity}</TableCell>
                                        <TableCell align="left">{row2.price}</TableCell>
                                    </TableRow>
                                  ))}
                                </TableCell>

                                <TableCell align="left" ><Button href={'/editOrder/'+row.orderId} ><CreateIcon /></Button></TableCell>
                                <TableCell align="left"><Button  onClick={() => this.deleteOrder(row.orderId)} ><DeleteIcon /></Button></TableCell>

                            </TableRow>
                        ))}

                    </TableBody>

                </Table>

                <Paper item xs={12} sm={12} md={12} lg={12} style={{width:'100%',height:'60px',marginTop:'30px',backgroundColor:'white'}}>
                      <Box style={{position:'relative',top:'10px',height:'40px',width:'265px',backgroundColor:'red',margin:'auto'}}>


                        <Button disabled={this.state.prwDisabled} onClick={()=>this.preview()} style={{float:'left' ,backgroundColor:'#03a9f4',color:'black',fontWeight:'bold',marginRight:'10px',height:'40px',color:'white'}}  >preview</Button>
                              <Typography style={{float:'left',color:'black',fontWeight:'bold',marginRight:'10px',marginTop:'5px',backgroundColor:'green',width:'60px',textAlign:'center'}} variant='h6'>{this.state.Current_page_no+1}</Typography>
                        <Button disabled={this.state.nxtDisabled} onClick={()=>this.next()}  style={{float:'right',backgroundColor:'#03a9f4',color:'black',fontWeight:'bold',width:'100px',height:'40px',color:'white'}}>Next</Button>


                      </Box>
                </Paper>


                <Box style={{display:this.state.visible,position: 'fixed',top: '0px',left:'0px',width:'100%',height:'100%',zIndex:'2', backgroundColor:'black',opacity:'0.8'}}  onClick={() => this.handlecoverHide()}></Box>
                {this.state.show&&(
                  <Alert variant="filled" severity="warning" style={{position: 'fixed',top:'300px',width: '550px',zIndex: '3',left: `${window.innerWidth/2-275}px`,color:'white'}}
                        action={
                            <Box style={{marginTop:'50px'}}>
                              <Button color="inherit" size="small" style={{fontSize:'14px'}} onClick={() => this.handlecoverHide()} >
                                Cancel
                              </Button>
                              <Button color="inherit" size="small" style={{fontSize:'14px'}} onClick={() => this.conformDeleteProduct()} >
                                Delete
                              </Button>
                            </Box>
                          }
                  >
                        <AlertTitle>Warning</AlertTitle>
                        Are you sure delete this product?

                  </Alert>
                )}
                {this.state.message&&(
                  <Alert variant="filled" severity="success" style={{position: 'fixed',top:'300px',width: '550px',zIndex: '4',left: `${window.innerWidth/2-275}px`,backgroundColor:'green',color:'white'}}>
                        <AlertTitle>success</AlertTitle>
                        {this.state.message}
                  </Alert>
                )}
                {this.state.error&&(
                  <Alert variant="filled" severity="error" style={{position: 'fixed',top:'300px',width: '550px',zIndex: '5',left: `${window.innerWidth/2-275}px`,color:'white'}}>
                        <AlertTitle>Failed!</AlertTitle>
                        Order delete failed
                  </Alert>
                )}



            </div>
        );
    }

}

export default OrderDetails;
