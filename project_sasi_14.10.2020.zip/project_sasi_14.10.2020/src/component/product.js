import React,{Component} from 'react';

import { AppBar, Typography,CardActionArea,CardMedia,Paper,Divider,Link, } from '@material-ui/core';

import { Card, CardContent, Grid, FormControl, TextField, InputLabel, OutlinedInput, Pape, Box,Select, Button,CardActions } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import FacebookIcon from '@material-ui/icons/Facebook';
import BottomNavigation from '@material-ui/core/BottomNavigation';
import './css/product.css';
import Rating from 'material-ui-rating'


import Alert from '@material-ui/lab/Alert';

import { ValidatorForm, TextValidator} from 'react-material-ui-form-validator';

import SignIn from './signIn';

import ApiService from "./../ApiService";



class Product extends Component {
    constructor(props){
      super(props)

      this.state={
          username:localStorage.getItem('username'),
          logInAlert:'none',

          productId: '',
          shopId: '',
          title:'',
          description: '',
          lastPrice: '',
          sellPrice: '',
          warranty: '',
          productRating: '',
          stock: '',
          brand: '',
          model: '',

          //this is shop data
          shopName: '',
          shopAddress: '',
          shopTelephone: '',
          shopLogo: '',
          shopRating: '',

          feedbacks:[],
          feedbackNum:0,

          image1:"",
          image2:"",
          image3:"",
          image4:"",
          image5:"",


          //img view set
          viewImg1:'',
          viewImg2:'',
          viewImg3:'',
          viewImg4:'',
          viewImg5:'',

          imgBtnBorder1:'1px solid black',
          imgBtnBorder2:'',
          imgBtnBorder3:'',
          imgBtnBorder4:'',
          imgBtnBorder5:'',



      };
    }
    //localStorage.setItem("hari","5f697e0d63723b695f7a0eb1");

    componentDidMount(){
      const productId = this.props.match.params.id;
      this.loadProduct(productId);

    }
    loadProduct = (productId) => {
        ApiService.getProductById(productId)
            .then((res) => {
                let product = res.data;
                this.setState({
                  productId: product.productId,
                  shopId: product.shopId,
                  title: product.title,
                  description: product.description,
                  lastPrice: product.lastPrice,
                  sellPrice: product.sellPrice,
                  warranty: product.warranty,
                  productRating: product.rating,
                  stock: product.stock,
                  brand: product.brand,
                  model: product.model,

                  image1:product.image1,
                  image2:product.image2,
                  image3:product.image3,
                  image4:product.image4,
                  image5:product.image5,

                })
                this.loadShop();
                this.reloadFeedback();
                this.countFeedback();
            });

    }

    //this is get product shop Details
    loadShop = () =>{
      ApiService.getShopById(this.state.shopId)
          .then((res) => {
              let shops = res.data;
              this.setState({
                  shopName: shops.shopName,
                  shopAddress: shops.address,
                  shopTelephone: shops.telephone,
                  shopLogo: shops.shopLogo,
                  shopRating: shops.rating,
              })
          });
    }





reloadFeedback = () =>{
  ApiService.getFeedbackByProductId(this.state.productId)
      .then((res) => {
        let item=res.data;
          //this.setState({feedbacks: res.data})
          if(item){
              {
                item.map(item =>(
                  ApiService.viewUserById(item.userId)
                      .then((res) => {

                          let feedbackerDetails = res.data;
                          this.setState(prevState => ({

                            feedbacks: [...prevState.feedbacks, {
                              "feedbackId":item.feedbackId,
                              "userId":item.userId,
                              "productId":item.productId,
                              "feedback":item.feedback,
                              "feedbackDate":item.feedbackDate,
                              "rating":item.rating,
                              "userName":feedbackerDetails.userName,

                            }]
                          }))
                      })
                ))
              }
            }
      });

}
countFeedback = () =>{
  ApiService.countFeedbackByProductId(this.state.shopId)
      .then((res) => {
          this.setState({feedbackNum: res.data})
      });
}





  handleChangeQuantity=(e) =>{
    this.setState({
      quantity:e.target.value,
    });
  }

  handleImgChange=(e) =>{
    if(e=='listImg1'){
        this.setState({
          viewImg1:'block',

          viewImg2:'none',
          viewImg3:'none',
          viewImg4:'none',
          viewImg5:'none',



          imgBtnBorder1:'1px solid black',

          imgBtnBorder2:'none',
          imgBtnBorder3:'none',
          imgBtnBorder4:'none',
          imgBtnBorder5:'none',
        });
    }else if (e=='listImg2'){
      this.setState({
        viewImg2:'block',

        viewImg1:'none',
        viewImg3:'none',
        viewImg4:'none',
        viewImg5:'none',


        imgBtnBorder2:'1px solid black',

        imgBtnBorder1:'none',
        imgBtnBorder3:'none',
        imgBtnBorder4:'none',
        imgBtnBorder5:'none',
      });
    }
    else if (e=='listImg3'){
      this.setState({
        viewImg3:'block',

        viewImg1:'none',
        viewImg2:'none',
        viewImg4:'none',
        viewImg5:'none',


        imgBtnBorder3:'1px solid black',

        imgBtnBorder2:'none',
        imgBtnBorder1:'none',
        imgBtnBorder4:'none',
        imgBtnBorder5:'none',
      });
    }
    else if (e=='listImg4'){
      this.setState({
        viewImg4:'block',

        viewImg1:'none',
        viewImg2:'none',
        viewImg3:'none',
        viewImg5:'none',


        imgBtnBorder4:'1px solid black',

        imgBtnBorder2:'none',
        imgBtnBorder3:'none',
        imgBtnBorder1:'none',
        imgBtnBorder5:'none',
      });
    }
    else if (e=='listImg5'){
      this.setState({
        viewImg5:'block',

        viewImg1:'none',
        viewImg2:'none',
        viewImg3:'none',
        viewImg4:'none',


        imgBtnBorder5:'1px solid black',

        imgBtnBorder2:'none',
        imgBtnBorder3:'none',
        imgBtnBorder4:'none',
        imgBtnBorder1:'none',
      });
    }
  }



      onChangeUsername = (e) => {
        this.setState({
          username: e.target.value
        });
      }

      onChangePassword = (e) => {
        this.setState({
          password: e.target.value
        });
      }




      buyItNowFun = (e) =>{
      {!this.state.username &&(
        this.setState({
          logInAlert:`${e}`,
        })
      )}


      }


      // addItem(feedback){
      //     alert(feedback.userId);
      //     this.setState(prevState => ({
      //       items: [...prevState.items, {
      //         "id":this.state.items.length,
      //         "name":feedback.userId,
      //       }]
      //     }))
      // }





  render(){

    const feedbacks = this.state.feedbacks;


    return(
      <div id="productMainDiv">
          <Paper id="productBox" elevation={3}>
                <Grid container>


                      <Grid item xs={12} sm={12} md={6} lg={6} id="imgGrid">
                            <Paper id='productImgBox' style={{marginTop:"20px"}} elevation={3}>
                                  <CardMedia
                                    Id='productImg1'
                                    component="img"
                                    image={this.state.image1}
                                    class="img-responsive"
                                    style={{display:this.state.viewImg1}}
                                  />
                                  <CardMedia
                                    Id='productImg2'
                                    component="img"
                                    image={this.state.image2}
                                    class="img-responsive"
                                    style={{display:this.state.viewImg2}}
                                  />
                                  <CardMedia
                                    Id='productImg3'
                                    component="img"
                                    image={this.state.image3}
                                    class="img-responsive"
                                    style={{display:this.state.viewImg3}}
                                  />
                                  <CardMedia
                                    Id='productImg4'
                                    component="img"
                                    image={this.state.image4}
                                    class="img-responsive"
                                    style={{display:this.state.viewImg4}}
                                  />
                                  <CardMedia
                                    Id='productImg5'
                                    component="img"
                                    image={this.state.image5}
                                    class="img-responsive"
                                    style={{display:this.state.viewImg5}}
                                  />
                            </Paper>
                            <Paper id="imgListBox" elevation={4}>
                              <Button id="imgBtn1" onClick={() => this.handleImgChange('listImg1')}   style={{border:this.state.imgBtnBorder1}}>
                                <CardMedia
                                  Id='listImg1'
                                  component="img"
                                  image={this.state.image1}
                                  class="img-responsive"

                                />
                              </Button>
                              <Button id="imgBtn2" onClick={() => this.handleImgChange('listImg2')} style={{border:this.state.imgBtnBorder2}}>
                                <CardMedia
                                  Id='listImg2'
                                  component="img"
                                  image={this.state.image2}
                                  class="img-responsive"

                                />
                              </Button>
                              <Button id="imgBtn3" onClick={() => this.handleImgChange('listImg3')}   style={{border:this.state.imgBtnBorder3}}>
                                <CardMedia
                                  Id='listImg3'
                                  component="img"
                                  image={this.state.image3}
                                  class="img-responsive"

                                />
                              </Button>
                              <Button id="imgBtn4" onClick={() => this.handleImgChange('listImg4')} style={{border:this.state.imgBtnBorder4}}>
                                <CardMedia
                                  Id='listImg4'
                                  component="img"
                                  image={this.state.image4}
                                  class="img-responsive"

                                />
                              </Button>
                              <Button id="imgBtn5" onClick={() => this.handleImgChange('listImg5')} style={{border:this.state.imgBtnBorder5}}>
                                <CardMedia
                                  Id='listImg5'
                                  component="img"
                                  image={this.state.image5}
                                  title="Contemplative Reptile"
                                  class="img-responsive"

                                />
                              </Button>
                            </Paper>
                      </Grid>

                      <Grid item xs={12} sm={12} md={6} lg={6} id="productInfoGrid">
                            <Paper id="productDetail" className="productDetail" elevation={0}>
                                <Typography gutterBottom  id='producViewTitle' elevation={0} variant="h5">
                                  {this.state.title}
                                </Typography>
                                <Box id='reviewInfoDiv' elevation={0}>
                                    <Box gutterBottom  id='ratingDiv' elevation={0} >
                                        <Rating name="read-only" value={this.state.productRating} readOnly style={{cursor:'pointer',width:'170px'}} title={this.state.productRating} /> <Link variant='span' id="reviewText" href="#feedbackMainDiv">{this.state.feedbackNum} Reviews</Link>
                                    </Box>
                                    <Typography gutterBottom  id='offer' elevation={0} variant="subtitle1">
                                        {this.state.lastPrice}
                                    </Typography>
                                    <Typography gutterBottom  id='sellPrice' elevation={0} variant="subtitle1">
                                        {this.state.sellPrice}
                                    </Typography>

                                    <Typography gutterBottom  id='warrantyDiv' elevation={0} variant="subtitle1">
                                      Warranty :- {this.state.warranty}
                                    </Typography>
                                    <Box gutterBottom  id='quantityDiv' elevation={0} variant="subtitle1">
                                      <Typography variant="span">Quantity :-</Typography>
                                        <FormControl variant="outlined" id="quantityIp">

                                            <Select
                                                Id="quantitySelect"
                                                native
                                                value={this.state.gender}
                                                onChange={this.handleChangeQuantity}
                                                inputProps={{
                                                  name:'quantity',
                                                  id:'outline-quantity-native-simple'
                                                }}
                                            >
                                                <option value={1}>1</option>
                                                <option value={2}>2</option>
                                                <option value={3}>3</option>
                                                <option value={4}>4</option>
                                                <option value={5}>5</option>
                                                <option value={6}>6</option>
                                                <option value={7}>7</option>
                                                <option value={8}>8</option>
                                                <option value={9}>9</option>
                                                <option value={10}>10</option>
                                            </Select>
                                        </FormControl>
                                    </Box>

                                </Box>


                                <Box id="buyBtnArea" elevation={0}>

                                    <Button Id="buyNowBtn" onClick={() => this.buyItNowFun('block')} >Buy Now</Button>

                                    <Button Id="addToCartBtn" >Add To Cart</Button>

                                </Box>




                                <Divider id='divider'/>
                                <Box id='sellerInfoDiv' elevation={0}>
                                    <Typography gutterBottom  id='soldByText' elevation={0} variant="p">
                                        SOLD BY :
                                    </Typography>
                                    <Typography gutterBottom  id='soldShopName' elevation={0} variant="h6" >
                                        <Link href={"/shop/"+this.state.shopId} id="shopLink">{this.state.shopName}</Link>
                                    </Typography>
                                    <Rating name="read-only" value={this.state.shopRating} readOnly style={{cursor:'pointer',width:'170px',marginTop:'-15px'}} title={this.state.shopRating} />
                                    <Typography gutterBottom  id='soldShopAddress' elevation={0} variant="p">
                                        {this.state.shopAddress}
                                    </Typography>

                                    <Typography gutterBottom  id='soldShopRating' elevation={0} variant="p">

                                    </Typography>
                                </Box>
                            </Paper>

                      </Grid>

                </Grid>

          </Paper>



          <Box id="loginAlertDivWaraper" style={{display:this.state.logInAlert}} onClick={() => this.buyItNowFun('none')} elevation={3}>
          </Box>

          <Paper id="loginAlertDiv" style={{}} style={{ display:this.state.logInAlert, left: `${window.innerWidth/2-300}px` }} >
              <SignIn />
          </Paper>



          {/* Description and feedback area */}

          <Paper id="DescriptionDivWarraper" elevation="3">
              <Grid container id="">
                    <Grid  item xs={12} >
                          <Typography id='descriptionHeading' variant="h5" id="desTitile" style={{marginLeft:'30px',marginTop:'20px'}}>Description</Typography>
                          <Box id="DescriptionDiv">
                          {this.state.description}
                          </Box>
                    </Grid>
              </Grid>
          </Paper>





          {/*feedback area */}

          <Paper id="feedbackMainDiv" elevation="3">

              <Grid container id="feedbackSection">
                  <Typography id='descriptionHeading' variant="h5" id="desTitile" style={{marginLeft:'30px',marginTop:'20px'}}>Rating And Feedbacks</Typography>




                  {
                    feedbacks.map(feedback =>(

                        <Paper  id="feedbackPaper" >
                            <Grid container>

                                <Grid  item xs={12} md={4} id="nameAndRatingDivGrid">
                                      <Box id="nameAndRatingDiv">


                                          <Typography id="raterName">{feedback.userName}</Typography>
                                          <Typography id="feedbackRating"><Rating name="read-only" value={feedback.rating} readOnly style={{}} /></Typography><Typography Id="feedbackRatingNumber">{feedback.rating}</Typography>
                                          <Typography id="ratingDate">{feedback.feedbackDate}</Typography>
                                      </Box>
                                </Grid>
                                <Grid  item xs={12} md={8} id="feedbackWarraperGrid">
                                      <Box id="feedbackDiv">
                                          <Typography id="feedbackText">{feedback.feedback}<br/><br/></Typography>
                                      </Box>
                                </Grid>

                            </Grid>
                        </Paper>
                  ))
              }













              </Grid>
          </Paper>



      </div>
    );
  }
}
export default Product;
